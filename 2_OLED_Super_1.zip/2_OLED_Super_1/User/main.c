﻿/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
*******************************************************************************/
#include "debug.h"
#include "OLED_Driver.h"
#include "Game_Engine.h"
#include "Game_Rules.h"
#include "Rocker.h"
#include "Level_Data.h"

#define LV_W        256
#define GRAVITY     2
#define MAX_FALL    15
#define WALK_SPEED  3
#define JUMP_VEL   -10

int main(void)
{
    uint8_t  fb[1024], level[LV_W * LEVEL_ROWS];
    Entity   entities[MAX_ENTITIES];
    uint8_t  entity_count = 0;
    int      ret;
uint8_t  i;
    uint8_t  mario_camera_y = 0;
    uint8_t  max_camera_y = LEVEL_ROWS - LEVEL_H_VIS;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    SystemCoreClockUpdate();
    Delay_Init();
    USART_Printf_Init(115200);
    printf("Mario 1-1\r\n");

    Rocker_Init_Config();
    OLED_Init();
    load_level_1_1(level, LV_W);

    /* 从刷怪表生成所有实体 */
    for(i = 0; i < level_1_1_spawn_count && i < MAX_ENTITIES; i++) {
        init_entity(&entities[i], level_1_1_spawns[i].type,
                    level_1_1_spawns[i].tx * 8, level_1_1_spawns[i].ty * 8);
        if(level_1_1_spawns[i].type == ET_MUSHROOM)
            entities[i].flags &= ~EF_ACTIVE;
        entity_count++;
    }
    printf("Spawned %d entities\r\n", entity_count);

    /* Mario 的摄像机 */
    entities[0].camera_x = 0;

    printf("Go\r\n");

    while(1) {
        /* ─── 1. 摇杆输入 ─── */
        int16_t dx = 0;
        if(Rocker_Get_Right_State()) dx = WALK_SPEED;
        if(Rocker_Get_Left_State())  dx = -WALK_SPEED;
        uint8_t jump = Rocker_Get_Z_State() || Rocker_Get_Up_State();

        entities[0].vx = dx;
        if(jump && (entities[0].flags & EF_GROUNDED))
            entities[0].vy = JUMP_VEL;

        /* ─── 2. Mario 物理 ─── */
        int16_t mario_prev_y  = entities[0].y;
        int16_t mario_prev_vy = entities[0].vy;
        move_entity(&entities[0], level, LV_W, GRAVITY, MAX_FALL);

        /* 顶砖块 */
        if(mario_prev_vy < 0 && entities[0].vy == 0 && (entities[0].y % 8 == 0)) {
            uint8_t hit_row = entities[0].y / 8 - 1;
            uint8_t c0 = entities[0].x / 8;
            uint8_t c1 = (entities[0].x + entities[0].w - 1) / 8;
            for(uint8_t c = c0; c <= c1; c++) {
                uint8_t tid = get_tile(level, LV_W, hit_row, c);
                if(tid == TID_QUEST) {
                    if(hit_tile(level, LV_W, hit_row, c)) {
                        if(entity_count < MAX_ENTITIES) {
                            init_entity(&entities[entity_count], ET_MUSHROOM,
                                        c * 8 + 2, (hit_row - LEVEL_TOP_VIS) * 8 - 8);
                            entities[entity_count].vx = 1;
                            entities[entity_count].facing = 0;
                            entities[entity_count].flags |= EF_ACTIVE;
                            entity_count++;
                        }
                    }
                } else if(tid == TID_BRICK && (entities[0].flags & EF_BIG)) {
                    break_tile(level, LV_W, hit_row, c);
                }
            }
        }

        if(entities[0].x < 0) entities[0].x = 0;

        /* ─── 3. 所有非 Mario 实体 AI + 物理 ─── */
        for(i = 1; i < entity_count; i++) {
            if(!(entities[i].flags & EF_ACTIVE)) continue;

            /* 板栗仔 / 蘑菇: 朝 facing 方向走 */
            entities[i].vx = (entities[i].facing == 0) ? 1 : -1;
            move_entity(&entities[i], level, LV_W, GRAVITY, MAX_FALL);
            if(entities[i].vx == 0)
                entities[i].facing = !entities[i].facing;

            /* 坠落销毁 */
            if(entities[i].y > (int16_t)(LEVEL_ROWS * 8) || entities[i].x < -32)
                entities[i].flags &= ~EF_ACTIVE;

            update_animation(&entities[i]);
        }

        /* ─── 4. Mario vs 实体碰撞 ─── */
        for(i = 1; i < entity_count; i++) {
            if((entities[i].flags & EF_ACTIVE) && entities[i].type == ET_GOOMBA)
                handle_entity_collision(&entities[0], &entities[i], mario_prev_y);
        }

        /* 无敌计时 */
        if(entities[0].hp > 1) entities[0].hp--;

        /* ─── 5. 蘑菇拾取 ─── */
        for(i = 1; i < entity_count; i++) {
            if(!(entities[i].flags & EF_ACTIVE)) continue;
            if(entities[i].type != ET_MUSHROOM) continue;
            if(entities[0].x + entities[0].w > entities[i].x &&
               entities[i].x + entities[i].w > entities[0].x &&
               entities[0].y + entities[0].h > entities[i].y &&
               entities[i].y + entities[i].h > entities[0].y) {
                if(!(entities[0].flags & EF_BIG)) {
                    entities[0].flags |= EF_BIG;
                    entities[0].h = 14;
                    entities[0].anim = &anim_mario_big_stand;
                }
                entities[i].flags &= ~EF_ACTIVE;
            }
        }

        /* ─── 6. 死亡检测 + 重置 ─── */
        if(entities[0].y > (int16_t)(LEVEL_ROWS * 8) || entities[0].x < -32 || entities[0].hp == 0) {
            printf("Respawn\r\n");
            entities[0].flags &= ~EF_BIG;
            entities[0].h = 7;
            load_level_1_1(level, LV_W);
            entity_count = 0;
            for(i = 0; i < level_1_1_spawn_count && i < MAX_ENTITIES; i++) {
                init_entity(&entities[i], level_1_1_spawns[i].type,
                            level_1_1_spawns[i].tx * 8, level_1_1_spawns[i].ty * 8);
                if(level_1_1_spawns[i].type == ET_MUSHROOM)
                    entities[i].flags &= ~EF_ACTIVE;
                entity_count++;
            }
            entities[0].camera_x = 0;
            mario_camera_y = 0;
            Delay_Ms(500);
        }

        /* ─── 7. 旗帜检测 ─── */
        {
            uint8_t fc = (entities[0].x + entities[0].w / 2) / 8;
            uint8_t fr = (entities[0].y + entities[0].h / 2) / 8 + LEVEL_TOP_VIS;
            if(fc < 32 && get_tile(level, LV_W, fr, fc) == TID_FLAG) {
                printf("Level Complete!\r\n");
                while(1);
            }
        }

        /* ─── 8. 摄像机 ─── */
        {
            int16_t sx = entities[0].x - entities[0].camera_x;
            if(sx < 32)      entities[0].camera_x = entities[0].x - 32;
            else if(sx > 80) entities[0].camera_x = entities[0].x - 80;
        }
        if(entities[0].camera_x < 0) entities[0].camera_x = 0;
        /* 垂直摄像机 */
        if(max_camera_y > 0) {
            int16_t mario_dy = entities[0].y - (LEVEL_TOP_VIS + mario_camera_y) * 8;
            if(mario_dy < 16 && mario_camera_y > 0) mario_camera_y--;
        else if(mario_dy > 48 && mario_camera_y < max_camera_y) mario_camera_y++;
        }

        /* ─── 9. 动画 ─── */
        {
            const AnimDef *prev_a = entities[0].anim;
            if(entities[0].flags & EF_BIG) {
                entities[0].anim = (entities[0].vx != 0) ?
                    &anim_mario_big_run : &anim_mario_big_stand;
            } else {
                entities[0].anim = (entities[0].vx != 0) ?
                    &anim_mario_run : &anim_mario_stand;
            }
            if(entities[0].vx != 0) entities[0].facing = (entities[0].vx < 0) ? 1 : 0;
        if(entities[0].anim != prev_a) {
                entities[0].frame_idx = 0;
                entities[0].frame_timer = 0;
            }
        }
        update_animation(&entities[0]);

        /* ─── 10. 渲染 ─── */
        render_frame(fb, level, LV_W, entities, entity_count, entities[0].camera_x, mario_camera_y);

        while(!OLED_IsIdle());
        ret = OLED_DisplayFrame(fb);
        (void)ret;
        Delay_Ms(20);
    }
}










