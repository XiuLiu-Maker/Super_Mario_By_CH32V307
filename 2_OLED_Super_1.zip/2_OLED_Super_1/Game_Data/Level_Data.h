﻿#ifndef __LEVEL_DATA_H__
#define __LEVEL_DATA_H__

#include <stdint.h>

#define LEVEL_1_1_W  256
#define MAX_ENTITIES 8

/* 刷怪点 */
typedef struct {
    uint8_t  type;   /* ET_MARIO / ET_GOOMBA / ET_MUSHROOM */
    uint16_t tx;     /* tile X (乘以8得像素) */
    uint16_t ty;     /* tile Y (乘以8得像素) */
} EntitySpawn;

extern const uint8_t      level_1_1[];
extern const EntitySpawn  level_1_1_spawns[];
extern const uint8_t      level_1_1_spawn_count;

void load_level_1_1(uint8_t *dst, uint16_t dst_w);

#endif
