﻿#include "Game_Rules.h"
#include "OLED_Tiles.h"

uint8_t hit_tile(uint8_t *level, uint16_t level_w,
                 uint8_t row, uint16_t col)
{
    uint8_t tid = get_tile(level, level_w, row, col);
    uint8_t props = (tid < TILE_COUNT) ? tile_props[tid] : 0;

    if(props & TP_BUMP) {
        level[(uint16_t)row * level_w + col] = TID_USED;
        return 1;
    }
    return 0;
}

void break_tile(uint8_t *level, uint16_t level_w,
                uint8_t row, uint16_t col)
{
    uint8_t tid = get_tile(level, level_w, row, col);
    uint8_t props = (tid < TILE_COUNT) ? tile_props[tid] : 0;
    if(props & TP_DESTROY)
        level[(uint16_t)row * level_w + col] = TID_EMPTY;
}

void handle_entity_collision(Entity *a, Entity *b, int16_t a_prev_y)
{
    if(!(a->flags & EF_ACTIVE) || !(b->flags & EF_ACTIVE)) return;
    /* 无敌帧跳过碰撞 */
    if(a->type == ET_MARIO && a->hp > 1) return;
    if(b->type == ET_MARIO && b->hp > 1) return;
    if(a->x + a->w <= b->x || b->x + b->w <= a->x) return;
    if(a->y + a->h <= b->y || b->y + b->h <= a->y) return;

    if(a_prev_y + a->h <= b->y + 4) {
        a->vy = -8;
        b->hp = 0;
        b->flags &= ~EF_ACTIVE;
    } else if(a->type == ET_MARIO && (a->flags & EF_BIG)) {
        /* 大 Mario 受伤 → 变小 + 弹起 + 无敌帧 */
        a->flags &= ~EF_BIG;
        a->h = 7;
        a->vy = -8;
        a->hp = 30;
    } else {
        a->hp = 0;
    }
}









