﻿/* =============================================================
 * Game_Rules.h - 游戏规则层 (基于属性决策)
 * ============================================================= */
#ifndef __GAME_RULES_H__
#define __GAME_RULES_H__

#include <stdint.h>
#include "Game_Engine.h"

/* 顶砖块: 检查 row,col 处 tile 是否可撞击, 是则改变状态
 * 返回 1 = 撞出东西（金币/蘑菇）*/
uint8_t hit_tile(uint8_t *level, uint16_t level_w,
                 uint8_t row, uint16_t col);

/* 破坏砖块: 检查是否可破坏 */
void break_tile(uint8_t *level, uint16_t level_w,
                uint8_t row, uint16_t col);

/* 实体间碰撞: 踩敌人 / 被敌人碰到 */
void handle_entity_collision(Entity *a, Entity *b, int16_t a_prev_y);

#endif

