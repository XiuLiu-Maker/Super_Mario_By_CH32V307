﻿#ifndef __GAME_ENGINE_H__
#define __GAME_ENGINE_H__

#include <stdint.h>
#include "OLED_Tiles.h"

#define LEVEL_ROWS      12
#define LEVEL_H_VIS     8
#define LEVEL_TOP_VIS   0

#define ET_NONE     0
#define ET_MARIO    1
#define ET_GOOMBA   2
#define ET_MUSHROOM 3
#define ET_MAX      4

#define EF_GRAVITY  0x01
#define EF_PLAYER   0x02
#define EF_GROUNDED 0x04
#define EF_ACTIVE   0x80
#define EF_BIG      0x08

typedef struct {
    const uint8_t *data;
    uint8_t  cols;
    uint8_t  pages;
    uint8_t  delay;
} AnimFrame;

typedef struct {
    const AnimFrame *frames;
    uint8_t  count;
} AnimDef;

typedef struct {
    int16_t  x, y;
    uint8_t  w, h;
    int16_t  vx, vy;
    uint8_t  type;
    uint8_t  flags;
    uint8_t  hp;
    uint8_t  facing;
    uint8_t  frame_idx;
    uint8_t  frame_timer;
    const AnimDef *anim;
    int16_t  camera_x;
} Entity;

typedef struct {
    uint8_t  w, h;
    uint8_t  flags;
    const AnimDef *anim;
} EntityDef;

extern const EntityDef entity_defs[ET_MAX];

uint8_t  get_tile(const uint8_t *level, uint16_t level_w,
                  uint8_t row, uint16_t col);
void     draw_sprite(uint8_t *fb, const uint8_t *data,
                     uint8_t cols, uint8_t pages,
                     int16_t px, int16_t py, uint8_t flip);
void     draw_entity(uint8_t *fb, const Entity *e, int16_t camera_x, uint8_t camera_y);
void     render_frame(uint8_t *fb, const uint8_t *level,
                      uint16_t level_w,
                      Entity *entities, uint8_t entity_count,
                      int16_t camera_x, uint8_t camera_y);
void     update_animation(Entity *e);
void     init_entity(Entity *e, uint8_t type, int16_t x, int16_t y);
void     move_entity(Entity *e, const uint8_t *level, uint16_t level_w,
                     uint8_t gravity, uint8_t max_fall);
uint8_t  check_collision(const uint8_t *level, uint16_t level_w,
                         int16_t ex, int16_t ey,
                         uint8_t ew, uint8_t eh);
extern const AnimDef anim_mario_stand;
extern const AnimDef anim_mario_run;
extern const AnimDef anim_mario_big_stand;
extern const AnimDef anim_mario_big_run;
uint8_t  is_solid(uint8_t tid);


#endif




