﻿#include "Game_Engine.h"

/* ─── 8×8 马里奥 ─── */
static const uint8_t data_mario_stand[8] = {
    0xA0,0xD2,0xFF,0x7F,0x7B,0x7E,0xD2,0xA0,
};
static const AnimFrame mario_stand_frames[] = {
    {data_mario_stand, 8, 1, 0},
};
const AnimDef anim_mario_stand = { mario_stand_frames, 1 };

static const uint8_t mario_run_1[8] = {
    0x20,0x92,0xFF,0x7F,0x7B,0x7E,0x92,0xA0,
};
static const uint8_t mario_run_2[8] = {
    0x20,0x92,0xFF,0x7F,0xFB,0xFE,0x92,0x20,
};
static const AnimFrame mario_run_frames[] = {
    {mario_run_1, 8, 1, 6},
    {mario_run_2, 8, 1, 6},
};
const AnimDef anim_mario_run = { mario_run_frames, 2 };

static const uint8_t data_goomba[8] = {
    0x98,0xF4,0xF2,0xBF,0xFF,0xF2,0xF4,0x98,
};
static const uint8_t data_goomba2[8] = {
    0x98,0xF4,0xF2,0xFF,0x3F,0xF2,0xF4,0x98,
};
static const AnimFrame goomba_walk_frames[] = {
    {data_goomba, 8, 1, 12},
    {data_goomba2, 8, 1, 12},
};
static const AnimDef anim_goomba_walk = { goomba_walk_frames, 2 };

/* ─── 蘑菇 ─── */
static const uint8_t data_mushroom[8] = {
    0x18,0x1C,0xFE,0xFF,0xFB,0xFA,0x1C,0x18
};
static const AnimFrame mushroom_frames[] = {
    {data_mushroom, 8, 1, 0},
};
static const AnimDef anim_mushroom = { mushroom_frames, 1 };

/* ─── 大 Mario ─── */
static const uint8_t data_big_stand[16] = {
    0x70,0xFC,0xFE,0xFF,0xE7,0xEF,0x74,0x24,
    0x8F,0xFF,0xF0,0x1F,0x1F,0xF0,0xFF,0x8F,
};
static const AnimFrame big_stand_frames[] = {
    {data_big_stand, 8, 2, 0},
};
const AnimDef anim_mario_big_stand = { big_stand_frames, 1 };

static const uint8_t data_big_run1[16] = {
    0x70,0xFC,0xFE,0xFF,0xE7,0xEF,0x74,0x24,
    0x70,0x7F,0x3E,0x3F,0xFC,0xFF,0xC3,0x03,
};
static const uint8_t data_big_run2[16] = {
    0x70,0xFC,0xFE,0xFF,0xE7,0xEF,0x74,0x24,
    0x1E,0x33,0xFF,0xFF,0x9F,0x3F,0x7F,0x49,
};
static const AnimFrame big_run_frames[] = {
    {data_big_run1, 8, 2, 6},
    {data_big_run2, 8, 2, 6},
};
const AnimDef anim_mario_big_run = { big_run_frames, 2 };

const EntityDef entity_defs[ET_MAX] = {
    [ET_NONE]   = { 0,  0,  0,                  0                },
    [ET_MARIO]  = { 8,  7, EF_GRAVITY | EF_ACTIVE, &anim_mario_stand  },
    [ET_GOOMBA] = { 8,  7, EF_GRAVITY | EF_ACTIVE, &anim_goomba_walk  },
    [ET_MUSHROOM] = { 8,  7, EF_GRAVITY | EF_ACTIVE, &anim_mushroom   },
};

uint8_t get_tile(const uint8_t *level, uint16_t level_w,
                 uint8_t row, uint16_t col)
{
    if(row >= LEVEL_ROWS) return 0;
    if(col >= level_w) return 0;
    return level[(uint16_t)row * level_w + col];
}

uint8_t is_solid(uint8_t tid)
{
    if(tid >= TILE_COUNT) return 0;
    return tile_props[tid] & TP_SOLID;
}

uint8_t check_collision(const uint8_t *level, uint16_t level_w,
                        int16_t ex, int16_t ey,
                        uint8_t ew, uint8_t eh)
{
    int16_t tx0 = ex / 8;
    int16_t tx1 = (ex + ew - 1) / 8;
    int16_t ty0 = ey / 8;
    int16_t ty1 = (ey + eh - 1) / 8;
    int16_t tx, ty;

    for(ty = ty0; ty <= ty1; ty++) {
        if(ty < 0 || ty >= (int16_t)LEVEL_ROWS) continue;
        for(tx = tx0; tx <= tx1; tx++) {
            if(tx < 0) continue;
            if(is_solid(get_tile(level, level_w, (uint8_t)ty, (uint16_t)tx)))
                return 1;
        }
    }
    return 0;
}

void move_entity(Entity *e, const uint8_t *level, uint16_t level_w,
                 uint8_t gravity, uint8_t max_fall)
{
    int16_t new_x, new_y;
    e->flags &= ~EF_GROUNDED;

    if(e->vx != 0) {
        int16_t step = (e->vx > 0) ? 1 : -1;
        if(!check_collision(level, level_w, e->x + step, e->y, e->w, e->h)) {
            new_x = e->x + e->vx;
            if(!check_collision(level, level_w, new_x, e->y, e->w, e->h)) {
                e->x = new_x;
            } else {
                if(e->vx > 0)
                    e->x = ((new_x + e->w - 1) / 8) * 8 - e->w;
                else
                    e->x = (new_x / 8) * 8 + 8;
                e->vx = 0;
            }
        } else {
            e->vx = 0;
        }
    }

    if(e->flags & EF_GRAVITY) {
        e->vy += gravity;
        if(e->vy > max_fall) e->vy = max_fall;
    }

    if(e->vy != 0) {
        new_y = e->y + e->vy;
        if(!check_collision(level, level_w, e->x, new_y, e->w, e->h)) {
            e->y = new_y;
        } else {
            if(e->vy > 0) {
                e->y = ((e->y + e->vy + e->h - 1) / 8) * 8 - e->h;
                e->flags |= EF_GROUNDED;
                if(check_collision(level, level_w, e->x, e->y, e->w, e->h))
                    e->y -= 8;
            } else {
                e->y = ((e->y + e->vy) / 8) * 8 + 8;
                if(check_collision(level, level_w, e->x, e->y, e->w, e->h))
                    e->y += 8;
            }
            e->vy = 0;
        }
    }

    if(!(e->flags & EF_GROUNDED) && e->vy >= 0) {
        int16_t foot_y = e->y + e->h + 1;
        if(check_collision(level, level_w, e->x, foot_y, e->w, 1))
            e->flags |= EF_GROUNDED;
    }
}

void draw_sprite(uint8_t *fb, const uint8_t *data,
                 uint8_t cols, uint8_t pages,
                 int16_t px, int16_t py, uint8_t flip)
{
    uint8_t  start_page = (uint8_t)(py >> 3);
    uint8_t  p;
    int16_t  c, si;

    for(p = 0; p < pages; p++) {
        uint8_t cur_page = start_page + p;
        if(cur_page >= 8) break;
        for(c = 0; c < (int16_t)cols; c++) {
            int16_t col = px + c;
            if(col >= 0 && col < 128) {
                si = flip ? (cols - 1 - c) : c;
                fb[cur_page * 128 + col] = data[p * cols + si];
            }
        }
    }
}

void draw_entity(uint8_t *fb, const Entity *e, int16_t camera_x, uint8_t camera_y)
{
    if(!(e->flags & EF_ACTIVE)) return;
    if(!e->anim || e->frame_idx >= e->anim->count) return;
    const AnimFrame *f = &e->anim->frames[e->frame_idx];
        int16_t dy = e->y - (int16_t)((LEVEL_TOP_VIS + camera_y) * 8);
    draw_sprite(fb, f->data, f->cols, f->pages,
                e->x - camera_x, dy, e->facing);
}

void update_animation(Entity *e)
{
    if(!e->anim || e->anim->count <= 1) return;
    e->frame_timer++;
    if(e->frame_timer >= e->anim->frames[e->frame_idx].delay) {
        e->frame_timer = 0;
        e->frame_idx++;
        if(e->frame_idx >= e->anim->count) e->frame_idx = 0;
    }
}

void init_entity(Entity *e, uint8_t type, int16_t x, int16_t y)
{
    if(type >= ET_MAX) return;
    const EntityDef *def = &entity_defs[type];
    e->x = x; e->y = y;
    e->type = type;
    e->vx = 0; e->vy = 0;
    e->w = def->w; e->h = def->h;
    e->anim = def->anim;
    e->flags = def->flags;
    e->hp = 1;
    e->facing = 0;
    e->frame_idx = 0;
    e->frame_timer = 0;
    e->camera_x = 0;
}

void render_frame(uint8_t *fb, const uint8_t *level, uint16_t level_w,
                  Entity *entities, uint8_t entity_count,
                  int16_t camera_x, uint8_t camera_y)
{
    uint16_t i;
    uint8_t  display_row;
    int16_t  tx2, c2;

    for(i = 0; i < 1024; i++) fb[i] = 0;

    int16_t tile_off  = camera_x % 8;
    int16_t first_col = camera_x / 8;

    for(display_row = 0; display_row < 8; display_row++) {
        uint8_t lr = LEVEL_TOP_VIS + camera_y + display_row;
        for(tx2 = -1; tx2 < 17; tx2++) {
            int16_t lc = first_col + tx2;
            if(lc < 0) continue;

            uint8_t tid = get_tile(level, level_w, lr, (uint16_t)lc);
            if(tid == 0 || tid >= TILE_COUNT) continue;

            int16_t sx = tx2 * 8 - tile_off;
            if(sx + 8 <= 0 || sx >= 128) continue;

            const uint8_t *td = tiles[tid];
            for(c2 = 0; c2 < 8; c2++) {
                int16_t fc = sx + c2;
                if(fc < 0 || fc >= 128) continue;
                fb[display_row * 128 + fc] = td[c2];
            }
        }
    }

    for(i = 0; i < entity_count; i++)
        draw_entity(fb, &entities[i], camera_x, camera_y);
}











