﻿#ifndef __OLED_TILES_H__
#define __OLED_TILES_H__

#include <stdint.h>

#define TID_EMPTY   0
#define TID_GROUND  1
#define TID_QUEST   2
#define TID_PT_L    3
#define TID_PT_R    4
#define TID_PB_L    5
#define TID_PB_R    6
#define TID_USED    7
#define TID_FLAG    8
#define TID_BRICK   9

#define TP_SOLID   0x01
#define TP_BUMP    0x02
#define TP_DESTROY 0x04
#define TP_COIN    0x08
#define TP_PIPE    0x10

/* 每个 8×8 tile = 8 bytes (1 page × 8 cols) */
static const uint8_t tile_empty[8] = {
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};

/* 地面: 实心砖 + 横缝 */
static const uint8_t tile_ground[8] = {
    0xA0,0xEF,0xDF,0xFF,0xFF,0x87,0x7C,0x7F,
};

/* 问号块: 外框 + 内部"?" */
static const uint8_t tile_question[8] = {
    0xFF,0x81,0x85,0x83,0xD3,0x8D,0x81,0xFF,
};

/* 管道口左 */
static const uint8_t tile_pipe_top_l[8] = {
    0xFF,0xFF,0x81,0x81,0x81,0x81,0x81,0x81,
};

/* 管道口右 */
static const uint8_t tile_pipe_top_r[8] = {
    0x81,0x81,0x81,0x81,0x81,0x81,0xFF,0xFF,
};

/* 管体左: 外壁 + 暗纹 */
static const uint8_t tile_pipe_body_l[8] = {
    0xFF,0xFF,0xAA,0x55,0xAA,0x55,0x00,0x00,
};

/* 管体右: 暗纹 + 外壁 */
static const uint8_t tile_pipe_body_r[8] = {
    0x00,0x00,0x55,0xAA,0x55,0xAA,0xFF,0xFF,
};

/* 旗帜方块 */
static const uint8_t tile_flag[8] = {
    0x00,0x00,0xFF,0x1F,0x1E,0x0E,0x0C,0x0C,
};

/* 砖块方块 */
static const uint8_t tile_brick[8] = {
    0xAA,0xEE,0xAA,0xBB,0xAA,0xEE,0xAA,0xBB,
};

/* 已使用方块 */
static const uint8_t tile_used[8] = {
    0xFF,0x81,0x81,0x81,0x81,0x81,0x81,0xFF,
};

#define TILE_COUNT  10
static const uint8_t tile_props[TILE_COUNT] = {
    [TID_EMPTY]  = 0,
    [TID_GROUND] = TP_SOLID,
    [TID_QUEST]  = TP_SOLID | TP_BUMP | TP_COIN,
    [TID_PT_L]   = TP_SOLID | TP_PIPE,
    [TID_PT_R]   = TP_SOLID | TP_PIPE,
    [TID_PB_L]   = TP_SOLID | TP_PIPE,
    [TID_PB_R]   = TP_SOLID | TP_PIPE,
    [TID_USED]    = TP_SOLID,
    [TID_FLAG]    = 0,
    [TID_BRICK]   = TP_SOLID | TP_DESTROY,
};

static const uint8_t * const tiles[] = {
    tile_empty,
    tile_ground,
    tile_question,
    tile_pipe_top_l,
    tile_pipe_top_r,
    tile_pipe_body_l,
    tile_pipe_body_r,
tile_used,
tile_flag,
    tile_brick,
};

#endif






