﻿#include "ch32v30x.h"
#include "Rocker.h"

// DMA����������
// __attribute__((aligned(4))) static volatile uint16_t dma_adc_buffer[2];  // [0]:X��, [1]:Y��
volatile uint16_t dma_adc_buffer[2];

// ������ֵ����������У׼ֵ������
#define JOY_THRESHOLD_HIGH   3000
#define JOY_THRESHOLD_LOW    1000
#define JOY_DEAD_ZONE_RANGE  200  // ������Χ

// Z�����Ŷ���
#define Z_KEY_PIN    GPIO_Pin_3
#define Z_KEY_PORT   GPIOA

void Rocker_Init_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    ADC_InitTypeDef ADC_InitStructure = {0};
    DMA_InitTypeDef DMA_InitStructure = {0};
    
    // 1. ʹ��GPIOAʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    
    // 2. ����PA0��PA1Ϊģ������ģʽ������ADC��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  // ��������ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 3. ����DMA1 Channel1 (��ӦADC1)
    DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->RDATAR;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)dma_adc_buffer;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = 2;  // 2��ͨ��
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;  // ѭ��ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    
    // 4. ����ADC1
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;           // ɨ��ģʽ
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;     // ����ת��
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 2;                // 2��ͨ��
    ADC_Init(ADC1, &ADC_InitStructure);
    
    // ����ADCͨ���Ͳ���ʱ��
    // ͨ��0 (PA0) - X��
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_239Cycles5);
    // ͨ��1 (PA1) - Y��
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_239Cycles5);
    
    ADC_DMACmd(ADC1, ENABLE);
    
    DMA_Cmd(DMA1_Channel1, ENABLE);

    ADC_Cmd(ADC1, ENABLE);
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);

    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
}

uint8_t Rocker_Get_Up_State(void)
{
    return (dma_adc_buffer[1] < JOY_THRESHOLD_LOW) ? 1 : 0;
}

uint8_t Rocker_Get_Down_State(void)
{
    return (dma_adc_buffer[1] > JOY_THRESHOLD_HIGH) ? 1 : 0;
}

uint8_t Rocker_Get_Left_State(void)
{
    return (dma_adc_buffer[0] < JOY_THRESHOLD_LOW) ? 1 : 0;
}

uint8_t Rocker_Get_Right_State(void)
{
    return (dma_adc_buffer[0] > JOY_THRESHOLD_HIGH) ? 1 : 0;
}

uint8_t Rocker_Get_Z_State(void)
{
    return !GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2);
}





