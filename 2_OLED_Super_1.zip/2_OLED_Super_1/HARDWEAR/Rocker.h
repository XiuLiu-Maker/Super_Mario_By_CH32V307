#ifndef __ROCKER_H__
#define __ROCKER_H__

void Rocker_Init_Config(void);

uint8_t Rocker_Get_Up_State(void);
uint8_t Rocker_Get_Down_State(void);
uint8_t Rocker_Get_Left_State(void);
uint8_t Rocker_Get_Right_State(void);
uint8_t Rocker_Get_Z_State(void);

#endif