﻿#include "ch32v30x.h"
#include "string.h"

/* ======================== SSD1306 参数 ======================== */
#define OLED_ADDRESS        0x78
#define OLED_CMD            0x00    /* 控制字节: Co=0,D/C=0 → 命令模式 */
#define OLED_DATA           0x40    /* 控制字节: Co=0,D/C=1 → 数据模式 */
#define OLED_WIDTH          128
#define OLED_HEIGHT         64
#define OLED_PAGE_COUNT     8
#define OLED_BUFFER_SIZE    1024

/* ======================== 全局 ======================== */
static uint8_t oled_buffer[OLED_BUFFER_SIZE];       /* DMA 缓冲区 */
static volatile uint8_t oled_busy = 0;               /* 非阻塞状态标志 */

/* ======================== 底层 I2C 原语 ======================== */

static void OLED_I2C_Init(void)
{
    GPIO_InitTypeDef gpio = {0};
    I2C_InitTypeDef i2c  = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);

    gpio.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9;
    gpio.GPIO_Mode  = GPIO_Mode_AF_OD;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio);

    GPIO_PinRemapConfig(GPIO_Remap_I2C1, ENABLE);

    i2c.I2C_ClockSpeed          = 400000;
    i2c.I2C_Mode                = I2C_Mode_I2C;
    i2c.I2C_DutyCycle           = I2C_DutyCycle_2;
    i2c.I2C_OwnAddress1         = 0x00;
    i2c.I2C_Ack                 = I2C_Ack_Enable;
    i2c.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_Init(I2C1, &i2c);

    I2C_Cmd(I2C1, ENABLE);
    I2C_DMACmd(I2C1, ENABLE);
}

static void OLED_DMA_Init(void)
{
    DMA_InitTypeDef dma  = {0};
    NVIC_InitTypeDef nvic = {0};

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel6);

    dma.DMA_PeripheralBaseAddr = (uint32_t)&(I2C1->DATAR);
    dma.DMA_MemoryBaseAddr     = (uint32_t)oled_buffer;
    dma.DMA_DIR                = DMA_DIR_PeripheralDST;
    dma.DMA_BufferSize         = OLED_BUFFER_SIZE;
    dma.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
    dma.DMA_MemoryInc          = DMA_MemoryInc_Enable;
    dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma.DMA_MemoryDataSize     = DMA_MemoryDataSize_Byte;
    dma.DMA_Mode               = DMA_Mode_Normal;
    dma.DMA_Priority           = DMA_Priority_VeryHigh;
    dma.DMA_M2M                = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel6, &dma);

    DMA_ITConfig(DMA1_Channel6, DMA_IT_TC, ENABLE);

    nvic.NVIC_IRQChannel                   = DMA1_Channel6_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1;
    nvic.NVIC_IRQChannelSubPriority        = 0;
    nvic.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&nvic);
}

/* ---- I2C 事务原语 ---- */

static int OLED_I2C_Start(void)
{
    uint32_t t;
    t = 50000; while(I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY) && --t);
    if(!t) return -1;
    I2C_GenerateSTART(I2C1, ENABLE);
    t = 50000; while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT) && --t);
    if(!t) return -2;
    I2C_Send7bitAddress(I2C1, OLED_ADDRESS, I2C_Direction_Transmitter);
    t = 50000; while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) && --t);
    if(!t) return -3;
    return 0;
}

static void OLED_I2C_Stop(void)
{
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
    I2C_GenerateSTOP(I2C1, ENABLE);
    while(I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY));
}

static int OLED_I2C_WriteByte(uint8_t data)
{
    uint32_t t = 50000;
    I2C_SendData(I2C1, data);
    while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTING) && --t);
    return (t == 0) ? -1 : 0;
}

static int OLED_WriteCmd(uint8_t cmd)
{
    int r;
    if((r = OLED_I2C_Start()) < 0) return r;
    if(OLED_I2C_WriteByte(OLED_CMD) < 0) return -4;
    if(OLED_I2C_WriteByte(cmd) < 0) return -5;
    OLED_I2C_Stop();
    return 0;
}

/* =============================================================
 * DMA 传输完成中断
 *   1. 关闭 DMA 通道
 *   2. I2C 硬件自动完成最后字节并生成 STOP（无需软件轮询 BTF）
 *   3. 清除忙标志
 * ============================================================= */
void DMA1_Channel6_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void DMA1_Channel6_IRQHandler(void)
{
    if(DMA_GetITStatus(DMA1_IT_TC6)) {
        DMA_ClearITPendingBit(DMA1_IT_TC6);
        DMA_Cmd(DMA1_Channel6, DISABLE);
        /* I2C 硬件会在当前字节完成后自动生成 STOP */
        I2C_GenerateSTOP(I2C1, ENABLE);
        oled_busy = 0;
    }
}

/* =============================================================
 * @brief  非阻塞显示一帧画面
 *
 * @param  frame_data  指向 1024 字节帧数据的指针
 * @return  0 = 已启动 DMA（正在传输）
 *         -1 = 上一次传输尚未完成，调用前请检查 OLED_IsIdle()
 *
 * T1 [轮询]: 列/页范围命令
 * T2 [DMA ]: 0x40 控制字节（轮询）→ 1024 字节（DMA）→ STOP（ISR）
 * ============================================================= */
int OLED_DisplayFrame(const uint8_t *frame_data)
{
    uint16_t i;
    int r;

    if(oled_busy) return -1;

    /* 拷贝到内部缓冲区 */
    for(i = 0; i < OLED_BUFFER_SIZE; i++)
        ((uint8_t*)oled_buffer)[i] = frame_data[i];

    /* === T1: 命令 === */
    if((r = OLED_I2C_Start()) < 0) return r;
    if(OLED_I2C_WriteByte(OLED_CMD) < 0
    || OLED_I2C_WriteByte(0x21)    < 0
    || OLED_I2C_WriteByte(0x00)    < 0
    || OLED_I2C_WriteByte(0x7F)    < 0
    || OLED_I2C_WriteByte(0x22)    < 0
    || OLED_I2C_WriteByte(0x00)    < 0
    || OLED_I2C_WriteByte(0x07)    < 0) return -6;
    OLED_I2C_Stop();

    /* === T2: 数据 === */
    if((r = OLED_I2C_Start()) < 0) return r;
    if(OLED_I2C_WriteByte(OLED_DATA) < 0) return -4;

    /* 启动 DMA, 此后 ISR 负责完成 + STOP */
    oled_busy = 1;
    DMA1_Channel6->MADDR = (uint32_t)oled_buffer;
    DMA_SetCurrDataCounter(DMA1_Channel6, OLED_BUFFER_SIZE);
    DMA_Cmd(DMA1_Channel6, ENABLE);
    return 0;
}

/* =============================================================
 * @brief  查询传输状态
 * @return 1 = 空闲，可以发送下一帧
 *         0 = 上一帧 DMA 传输尚未完成
 * ============================================================= */
uint8_t OLED_IsIdle(void)
{
    return (oled_busy == 0);
}

/* =============================================================
 * 工具函数
 * ============================================================= */
void OLED_ClearBuffer(void)
{
    uint16_t i;
    for(i = 0; i < OLED_BUFFER_SIZE; i++)
        ((uint8_t*)oled_buffer)[i] = 0x00;
}

void OLED_FillBuffer(void)
{
    uint16_t i;
    for(i = 0; i < OLED_BUFFER_SIZE; i++)
        ((uint8_t*)oled_buffer)[i] = 0xFF;
}

/* =============================================================
 * @brief  初始化 SSD1306
 * ============================================================= */
void OLED_Init(void)
{
    OLED_I2C_Init();
    OLED_DMA_Init();
    Delay_Ms(10);

    OLED_WriteCmd(0xAE);
    OLED_WriteCmd(0x20); OLED_WriteCmd(0x00);
    OLED_WriteCmd(0x40);
    OLED_WriteCmd(0xA1);
    OLED_WriteCmd(0xC8);
    OLED_WriteCmd(0xA6);
    OLED_WriteCmd(0xA8); OLED_WriteCmd(0x3F);
    OLED_WriteCmd(0xD3); OLED_WriteCmd(0x00);
    OLED_WriteCmd(0xD5); OLED_WriteCmd(0x80);
    OLED_WriteCmd(0xD9); OLED_WriteCmd(0xF1);
    OLED_WriteCmd(0xDA); OLED_WriteCmd(0x12);
    OLED_WriteCmd(0xDB); OLED_WriteCmd(0x30);
    OLED_WriteCmd(0x8D); OLED_WriteCmd(0x14);
    Delay_Ms(10);
    OLED_WriteCmd(0xAF);
}
