#ifndef __OLED_DRIVER_H__
#define __OLED_DRIVER_H__

void OLED_Init(void);
int  OLED_DisplayFrame(const uint8_t* frame_data);
uint8_t OLED_IsIdle(void);
void OLED_ClearBuffer(void);
void OLED_FillBuffer(void);

#endif
